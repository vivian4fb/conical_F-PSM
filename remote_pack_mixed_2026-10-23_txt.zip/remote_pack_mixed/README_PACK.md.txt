# README_PACK — the mixed phase–absorption leg of the conical F-PSM test

*Pack built 2026-10-23 on the benchmark PC from `1_Optics/Research/conical revision/`. British English.*

## What this is about, in one paragraph

A closed-form diffraction-efficiency model for volume holographic gratings, **F-PSM**, was
benchmarked in September and October 2026 against an independent Python RCWA referee and the RCWA
solvers of Ansys Lumerical and Ansys Zemax OpticStudio: in-plane replay first, then (20–23 October)
the full **conical** geometry, where Lumerical agreed with the referee to 4–8 × 10⁻⁵ on 601 rows
and the model's author's certified error bounds were all confirmed. On 23 October the author sent
his revised reports with the **mixed phase–absorption extension**: the index inside the slab is
`N = n0 + n1 cos(Kξ) − i [κ0 + κ1 cos(Kξ + δ)]`, i.e. a phase grating and an absorption grating of
the same period with a relative phase δ, plus a mean loss κ0. He asked whether these cases can be
tested on Ansys. On the benchmark PC his evaluator (shipped verbatim in `code/david_mixed/`) and his
1044-point sweep were reproduced by an independent complex-permittivity conical referee (eleven
gates, `evidence/mixed_gates.txt`, VERIFIED 2026-10-23). **What is missing is the Ansys data**:
Lumerical's RCWA on absorbing gratings at conical incidence. This pack exists to produce it. The
only new solver-facing element is the complex index; everything lossless reuses the drivers that
ran on this machine on 2026-10-23 (`reference/conical_leg_verdict_2026-10-23.md`).

## The brief

| product on this machine | brief | produces |
|---|---|---|
| Ansys Lumerical (2025 R1 or later, RCWA solver licensed) | `EXECUTION_MIXED_LUMERICAL.md` | a loss-probe log and `results/loss_route.json`, `results/lumerical_mixed_<case_id>.csv` for up to 100 configs, a convergence check, `results/summary_mixed.csv`, the figures, a verdict |

## Layout

```
CLAUDE.md                         start here
README_PACK.md                    this file
EXECUTION_MIXED_LUMERICAL.md      the brief: procedure, gates, the numbers to hit, pitfalls
RETURN_MIXED.md                   what to bring back and how it is merged
code/                             every script; run from here
  cases_mixed.py                  THE config definitions (single source of truth): sets P, A, B, C, D
  mixed_material.py               the complex index profile and the material matrices for the referee
  rcwa_conical.py  basis.py       the conical vector RCWA referee (takes complex permittivity; gated)
  fresnel_slab.py                 exact uniform absorbing slab: the loss probe's oracle
  david_mixed.py  david_mixed/    the author's own evaluator and RCWA, verbatim, SHA-256-checked on import
  test_mixed.py                   the eleven mixed gates (run in step 0)
  test_conical.py  sweep_david.py the twelve lossless conical gates (run in step 0)
  lumerical_rcwa_mixed.py         the mixed driver: loss probe, two complex-index routes, sets  ** complex index UNTESTED at the solver **
  lumerical_rcwa_conical.py       the conical driver it builds on (VERIFIED at the solver 2026-10-23)
  lumerical_rcwa.py               the September/October planar driver underneath (VERIFIED 2026-09-18)
  compare_mixed.py                scores + figures; run after every set
  mock_lumerical_mixed.py  dryrun_mixed.py   the test double and the dry run used on the benchmark PC; not needed here
  cases.py rcwa.py fpsm.py kogelnik*.py compare_conical.py ...   the earlier benchmark code (unchanged)
results/reference_mixed.csv       THE NUMBERS TO HIT: referee, the author's RCWA and closed forms on every row (1007 rows)
results/configs_mixed.json        the 100 configs with their angle lists
results/sweep_1044.csv            the author's 1044-point sweep re-run here (reference only)
results/reference_conical.csv     the lossless conical reference of the previous leg
evidence/mixed_gates.txt          the eleven gates passed on the benchmark PC; conical_gates.txt the twelve lossless ones
reference/                        the author's revised reports and response (23 Oct 2026), the conical leg's verdict,
                                  convergence ladder and summary, the September verdicts and Ansys article texts,
                                  the 2026-09-18 probe dump (every property and result name)
lumerical/ansys_example/          the Lumerical article's model (vhg_R_6um_model.fsp) -- do not modify
figures/                          the benchmark PC's figures (yours are added by compare_mixed.py)
```
