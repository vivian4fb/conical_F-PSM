CONICAL F-PSM: RESPONSE AND REVISED REPORTS
23 October 2026

DOCUMENTS
Response_to_Referee.pdf: three-page draft response to Vivian Amos Sureshkumar.
lossless/Conical_F_PSM_RCWA_Report.pdf: revised original lossless report.
mixed/Conical_F_PSM_Mixed_Report.pdf: revised combined phase/absorption report.
All three have editable LaTeX sources. Original 20 October output files have
not been overwritten. The independent referee's PDF, code and commercial
solver models are not redistributed in this archive.

REVISION SCOPE
1. Use D (diagonal wave-number matrix) and calligraphic A (reciprocal-
   permittivity convolution) to distinguish operator order in Section 2.C.
   The archived equation already had the correct ordering.
2. Define the leading scattering-plane channels from the actual incident
   and diffracted wavevectors. Prove the off-Bragg first-order separation
   and give a 504-point direct four-state/scalar check in Section 4.A.
3. Document the backward-companion degeneracy in Appendix B.D. Reject
   exact/near zero gaps explicitly in ordinary and validated evaluators.
   No denominator is shifted; no new degenerate solution is supplied.
4. Keep all original numerical tables and certificate bounds unchanged.
   No external validation of the mixed extension is claimed.

REPRODUCIBILITY
The code/lossless and code/mixed directories retain the complete original
calculations/data with guard-only evaluator revisions. Their READMEs describe
the original calculations; the present file governs the revision package.
The baseline directory holds the unchanged evaluator copies used by the
regression check. Run from the archive root, with the dependencies from
code/lossless/requirements.txt installed (Python 3.12 was used):

  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check_revision.py lossless
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check_revision.py mixed
  python code/lossless/verify_saved_certificates.py
  python code/mixed/verify_saved_certificates.py

The revision check compares every ordinary closed Jones matrix with its
baseline, re-evaluates all archived closed-model balls at recorded precision,
and checks that exact/near backward degeneracies are rejected by both
ordinary and ball evaluators. The lossless check also reassembles the
first-order four-state problem and recomputes all 504 archived RCWA
leading/corrected errors. Full depth-supremum and infinite-tail enclosure
generation was not rerun for this guard-only change. The separate saved-ball
checks verify final exported inequalities, not their enclosure generation.

RESULTS
504 lossless and 1044 mixed/pure-absorption predictions unchanged.
Scalar vs direct first-order four-state maximum Jones norm: 1.4185602503e-13.
Maximum efficiency-metric difference: 9.0405992285e-14.
Archived leading and corrected lossless error values reproduced exactly at
stored floating precision.
123 closed-model ball records compatible: 54 finite and 69 full Maxwell.
Both serialized certificate arithmetic checks passed.
Exact and near-degenerate normal-incidence tests now raise domain errors.
These are regression/identity checks; no new physical certificate is claimed.

MANUSCRIPT BUILDS
From the archive root:
  pdflatex Response_to_Referee.tex
  pdflatex Response_to_Referee.tex

From lossless/:
  pdflatex Conical_F_PSM_RCWA_Report.tex
  bibtex Conical_F_PSM_RCWA_Report
  pdflatex Conical_F_PSM_RCWA_Report.tex
  pdflatex Conical_F_PSM_RCWA_Report.tex

From mixed/:
  pdflatex Conical_F_PSM_Mixed_Report.tex
  bibtex Conical_F_PSM_Mixed_Report
  pdflatex Conical_F_PSM_Mixed_Report.tex
  pdflatex Conical_F_PSM_Mixed_Report.tex

The response uses standard LaTeX packages including newpxtext/newpxmath.
The reports include the official Optica class/styles used in the originals.
Figure PDFs are supplied; the mixed report inputs mixed_extension.tex.
Equation numbering in the reviewed lossless edition is preserved.

INTEGRITY
reviewed_file_hashes.json identifies the original PDFs/source inspected.
MANIFEST_SHA256.txt identifies the supplied revised package files.
The response is a draft for author review; no message has been sent.
