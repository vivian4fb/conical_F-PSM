REVISION NOTICE, 23 OCTOBER 2026
The evaluators in this copy include explicit backward-companion gap guards.
The root README.txt and check_revision.py describe the changes and checks.
The original study documentation follows; its standalone manuscript build
commands apply within the corresponding revised manuscript subdirectory.

CONICAL F-PSM: MIXED PHASE AND ABSORPTION EXTENSION
20 October 2026

MODEL
Time convention exp(+i omega t), passive index N=n-i kappa.
N(xi)=n0+n1*cos(K*xi+phase)-i*(kap0+kap1*cos(K*xi+phase+delta)).
Real identical transparent exteriors n0, nonmagnetic isotropic slab.
Lengths and vacuum wavelength are in micrometres; angles in degrees.
Require n0>|n1| and kap0>=|kap1|. The closed evaluator restricts the
l1 norm of (N-n0)/n0 to below 0.2, including mean absorption.
Both independent complex harmonics are retained. They are not generally
conjugates. Phase and absorption have the same grating vector.

CONTENTS
mixed_closed.py: standard-library closed evaluator; cubic bulk and quadratic
  face construction from the PSM/Bremmer surface-directed vertex. Includes
  a confluent finite exponential for one-sided Fourier spectra.
profile.py: exact Laurent products and reciprocal-permittivity coefficients.
mixed_rcwa.py: independent conical Moharam Fourier matrix and scattering
  composition; general complex Galerkin option for the residual proof.
mixed_validated.py: Arb evaluation, validated field suprema and full tail.
phase_closed.py, phase_rcwa.py: compatibility helpers copied from the
  lossless study, used by the mixed evaluator and limiting-case audit.
benchmark.py: declared 1044 cases; data in benchmark.csv and summary JSON.
certify.py: 30 finite and 42 infinite-order Maxwell certificates.
audit.py: reciprocal Fourier, lossless limit, radical/confluent evaluation,
  uniform absorbing Fresnel slab and all-polarisation Poynting tests.
verify_saved_certificates.py: independently repeat final bound arithmetic
  from exported Jones and edge-field balls, without solving RCWA again.
phase_scan.py: illustrative relative-phase scan, additional to the sweep.
figures.py: figures from saved data, accepts an output directory argument.

REPRODUCTION
Tested numerical runtime: Python 3.12, NumPy 2.3.5, SciPy 1.18.1,
python-flint 0.9.0. Figures used Matplotlib 3.11.1. Install requirements.txt
in your own environment. Run from this directory:

  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python benchmark.py
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python certify.py finite
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python certify.py physical
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python audit.py
  python verify_saved_certificates.py
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python phase_scan.py
  python figures.py ../../figures

Full certificate regeneration takes several minutes; the serialized check
is fast. Set the figures output argument appropriately outside the archive.
The compatibility helpers are imported modules; the advertised entry points
are the commands above.

RESULTS AND SCOPE
1044 cases: 972 mixed, 72 pure absorption. No closed-form rejections.
Maximum corrected observed absolute efficiency error: 3.8593021856e-5.
Maximum leading error: 5.8793210610e-3.
963 strict improvements; 81 one-sided cases suppress the selected order.
Largest 15-to-19-order change: 1.9960339716e-11 (observation, not a bound).
30 finite 19-order certificates: maximum upper bound 4.2906574e-6.
42 full Maxwell certificates: maximum upper bound 3.0154697e-7.
Maximum contraction bound: 0.36893835; maximum separate efficiency-tail
bound: 5.9668941e-13. All bounds are uniform over unit complex incident
Jones vectors at each specified exact parameter point.

The entire 1044-case sweep is not certified against the infinite problem.
Full certificates apply to the separately declared thinner cases and need
rho<1. No continuous angular/thickness domain, parameter uncertainty,
strongly absorbing background, absorbing exterior, or gain medium is
certified. The report retains the previous lossless results separately.

CERTIFICATE SEMANTICS
Physical inputs in certificate JSON are exact decimal strings. For example,
13.333333333333334 is that decimal, not an exact symbolic 40/3. Irrational
constants and subsequent operations use outward ball arithmetic. Finite
certificates compare 160/224 bits; full certificates use 512 bits with
128 depth panels and degree 32, checked against a separate 384-bit,
7-order computation. Nonfinite enclosures are rejected. Known nonnegative
squared norms are intersected with [0,infinity) before square roots.
Exported efficiency upper bounds below 1e-90 are conservatively rounded up
to 1e-90 so serialization widening is covered in exact-zero cases. All
saved final inequalities pass the separate serialized-ball check. That
check verifies exported arithmetic; it does not independently generate or
prove the saved RCWA and depth-supremum enclosures.
